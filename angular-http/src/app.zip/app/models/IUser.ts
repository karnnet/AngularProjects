export interface IUser{
    id?:string;
    title:string;
    status:string;
}