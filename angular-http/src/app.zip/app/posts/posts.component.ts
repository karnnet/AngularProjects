import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { IPost } from '../models/IPost';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit ,OnChanges{
posts:IPost[]=[];
  constructor(private postService:PostService) { }
  ngOnChanges(changes: SimpleChanges): void {
    
  }

  ngOnInit(): void {
    this.postService.getPosts().subscribe(posts=>{
      this.posts=posts;
      
    });
    console.log("post Component is loaded")
    console.log(this.posts)
  }

}
