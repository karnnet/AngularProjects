import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { PostsComponent } from './posts/posts.component';
import { HeaderComponent } from './header/header.component';
import { UsersComponent } from './Users/components/users/users.component';
import { AdduserComponent } from './Users/components/adduser/adduser.component';
import { ReactiveFormsModule } from '@angular/forms';
import { EditUserComponent } from './Users/components/edit-user/edit-user.component';
import { AddPostFormComponent } from './add-post-form/add-post-form.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PostsComponent,
    HeaderComponent,
    UsersComponent,
    AdduserComponent,
    EditUserComponent,
    AddPostFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
