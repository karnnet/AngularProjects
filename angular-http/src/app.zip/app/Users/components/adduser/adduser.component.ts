import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
userForm:FormGroup=new FormGroup({
  title:new FormControl('',[Validators.required]),
  status:new FormControl('active'),
})
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit(): void {
  }
  onAddUser(){
    let user=this.userForm.value;
    this.userService.addUser(user).subscribe((data)=>{
      this.router.navigate(['/users']);
    });
  }

}
