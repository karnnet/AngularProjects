import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddPostFormComponent } from './add-post-form/add-post-form.component';
import { HomeComponent } from './home/home.component';
import { PostsComponent } from './posts/posts.component';
import { AdduserComponent } from './Users/components/adduser/adduser.component';
import { EditUserComponent } from './Users/components/edit-user/edit-user.component';
import { UsersComponent } from './Users/components/users/users.component';

const routes: Routes = [
  {  path:'',component:HomeComponent},
  {  path:'posts',component:PostsComponent,
  children:[
    {path:'addPost',component:AddPostFormComponent}
  ]
},
  {  path:'users',component:UsersComponent},
  {  path:'user/add',component:AdduserComponent},
  {  path:'user/:id/edit',component:EditUserComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
